﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD_USUARIO.DATA
{
    public class Configuracion
    {
        public static string Conexion = "Data Source=.;Initial Catalog=DBPRUEBAS;Integrated Security=True";
    }
}
